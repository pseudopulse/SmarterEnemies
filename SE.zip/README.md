# Smarter Enemies
lmao get ratio'd by smarter enemies, better move quickly if you wanna actually win

list of things enemies can do now:
- pick up items (items are added to a permanent pool evolution style)
- open chests
- print items
- activate the teleporter

config to let allies do this too, by default enemies have a 35% chance to be able to open chests
